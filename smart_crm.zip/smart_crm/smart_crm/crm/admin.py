from django.contrib import admin
from .models import Customer, Lead

admin.site.register(Customer)
admin.site.register(Lead)
